// --- NAVIGATION LOGIC ---
function goTo(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    // Show target page
    const target = document.getElementById('page-' + pageId);
    if (target) target.classList.add('active');
    
    // Auto-close sidebar on mobile after navigation
    if (window.innerWidth <= 900) closeSidebar();
}

function showSection(sectionId, btn) {
    // Update Sidebar Active State
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    btn.classList.add('active');

    // Toggle Section Visibility
    document.querySelectorAll('.section-panel').forEach(s => s.classList.remove('active'));
    document.getElementById('section-' + sectionId).classList.add('active');

    // Update Topbar Title
    document.getElementById('pageTitle').innerText = btn.innerText.trim();
}

// --- SIDEBAR TOGGLE ---
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('open');
}

function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('open');
}

// --- LOAN CALCULATOR LOGIC ---
const amountRange = document.querySelectorAll('input[type="range"]')[0];
const termRange = document.querySelectorAll('input[type="range"]')[1];

function updateLoan() {
    const principal = parseInt(amountRange.value);
    const months = parseInt(termRange.value);
    const interestRate = 0.05; // 5% annual
    
    const totalInterest = principal * (interestRate * (months / 12));
    const totalAmount = principal + totalInterest;
    const monthly = totalAmount / months;

    document.querySelectorAll('.range-val')[0].innerText = `₱ ${principal.toLocaleString()}`;
    document.querySelectorAll('.range-val')[1].innerText = `${months} months`;
    document.querySelectorAll('.lr-val')[0].innerText = `₱ ${Math.round(monthly).toLocaleString()}`;
    document.querySelectorAll('.lr-val')[1].innerText = `₱ ${Math.round(totalInterest).toLocaleString()}`;
    document.querySelectorAll('.lr-val')[2].innerText = `₱ ${Math.round(totalAmount).toLocaleString()}`;
}

amountRange?.addEventListener('input', updateLoan);
termRange?.addEventListener('input', updateLoan);

// --- BACKEND INTEGRATION (FETCH API) ---
async function handleLogin(event) {
    event.preventDefault();
    const email = document.querySelector('input[type="email"]').value;
    
    // Example of calling a Python (Flask) API
    try {
        const response = await fetch('http://localhost:5000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email })
        });
        const data = await response.json();
        if(data.success) goTo('dashboard');
    } catch (error) {
        console.error("Backend offline, bypassing for demo...");
        goTo('dashboard');
    }
}

function validateAge() {
  const birthdateInput = document.getElementById('birthdate');
  const ageDisplay = document.getElementById('age-display');
  const registerBtn = document.querySelector('#page-register .btn-green');
  
  if (!birthdateInput.value) return;

  const birthDate = new Date(birthdateInput.value);
  const today = new Date();
  
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  
  // Adjust age if birthday hasn't happened yet this year
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  if (age < 18) {
    ageDisplay.textContent = `Age: ${age} (You must be at least 18)`;
    ageDisplay.style.color = "var(--danger)";
    registerBtn.disabled = true;
    registerBtn.style.opacity = "0.5";
  } else {
    ageDisplay.textContent = `Age: ${age} years old`;
    ageDisplay.style.color = "var(--teal)";
    registerBtn.disabled = false;
    registerBtn.style.opacity = "1";
  }
}